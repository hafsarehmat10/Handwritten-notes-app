import 'package:flutter/material.dart';

class Stroke {
  final List<Offset> points;
  final Color color;
  final double width;
  Stroke(this.points, this.color, this.width);
}

class Folder {
  final String id;
  String name;
  Folder(this.id, this.name);
}

class PlanItem {
  final String id;
  String text;
  bool done;
  PlanItem(this.id, this.text, {this.done = false});
}

class Note {
  final String id;
  final String title;
  final List<Stroke> strokes;
  final Size size;
  final DateTime created;
  String? folderId;
  Note(this.id, this.title, this.strokes, this.size, this.created,
      {this.folderId});
}

class NotesStore extends ChangeNotifier {
  static final NotesStore instance = NotesStore._();
  NotesStore._();

  final List<Note> notes = [];
  final List<Folder> folders = [];
  final List<PlanItem> plans = [];
  bool dark = false;

  String newId() => DateTime.now().microsecondsSinceEpoch.toString();

  // ---- notes ----
  void addNote(Note n) {
    notes.insert(0, n);
    notifyListeners();
  }

  void deleteNote(String id) {
    notes.removeWhere((n) => n.id == id);
    notifyListeners();
  }

  void clearAll() {
    notes.clear();
    folders.clear();
    plans.clear();
    notifyListeners();
  }

  List<Note> notesIn(String? folderId) => folderId == null
      ? notes
      : notes.where((n) => n.folderId == folderId).toList();

  // ---- folders ----
  void addFolder(String name) {
    folders.add(Folder(newId(), name));
    notifyListeners();
  }

  void deleteFolder(String id) {
    folders.removeWhere((f) => f.id == id);
    for (final n in notes) {
      if (n.folderId == id) n.folderId = null;
    }
    notifyListeners();
  }

  // ---- daily plan ----
  void addPlan(String text) {
    plans.insert(0, PlanItem(newId(), text));
    notifyListeners();
  }

  void togglePlan(PlanItem p) {
    p.done = !p.done;
    notifyListeners();
  }

  void deletePlan(String id) {
    plans.removeWhere((p) => p.id == id);
    notifyListeners();
  }

  void setDark(bool v) {
    dark = v;
    notifyListeners();
  }
}

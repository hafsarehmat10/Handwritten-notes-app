import 'package:flutter/material.dart';
import 'store.dart';
import 'screens/dashboard_screen.dart';

void main() => runApp(const NotesApp());

class NotesApp extends StatelessWidget {
  const NotesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: NotesStore.instance,
      builder: (context, _) {
        return MaterialApp(
          title: 'Handwritten Notes',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
          darkTheme: ThemeData(
              colorSchemeSeed: Colors.indigo,
              brightness: Brightness.dark,
              useMaterial3: true),
          themeMode: NotesStore.instance.dark ? ThemeMode.dark : ThemeMode.light,
          home: const DashboardScreen(),
        );
      },
    );
  }
}

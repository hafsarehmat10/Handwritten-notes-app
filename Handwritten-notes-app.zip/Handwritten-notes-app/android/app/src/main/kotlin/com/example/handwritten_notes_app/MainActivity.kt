package com.example.handwritten_notes_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

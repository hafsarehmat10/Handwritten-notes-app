import 'dart:ui' show PointMode;
import 'package:flutter/material.dart';
import 'store.dart';

void goTo(BuildContext context, Widget screen) {
  Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
}

class StrokePainter extends CustomPainter {
  final List<Stroke> strokes;
  StrokePainter(this.strokes);

  @override
  void paint(Canvas canvas, Size size) {
    for (final s in strokes) {
      final paint = Paint()
        ..color = s.color
        ..strokeWidth = s.width
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..style = PaintingStyle.stroke;
      if (s.points.length == 1) {
        canvas.drawPoints(PointMode.points, s.points, paint);
      } else {
        final path = Path()..moveTo(s.points.first.dx, s.points.first.dy);
        for (final p in s.points.skip(1)) {
          path.lineTo(p.dx, p.dy);
        }
        canvas.drawPath(path, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant StrokePainter old) => true;
}

class NoteThumb extends StatelessWidget {
  final Note note;
  const NoteThumb({super.key, required this.note});

  @override
  Widget build(BuildContext context) {
    return ClipRect(
      child: Container(
        color: Colors.white,
        child: FittedBox(
          fit: BoxFit.contain,
          child: SizedBox(
            width: note.size.width,
            height: note.size.height,
            child: CustomPaint(painter: StrokePainter(note.strokes)),
          ),
        ),
      ),
    );
  }
}
